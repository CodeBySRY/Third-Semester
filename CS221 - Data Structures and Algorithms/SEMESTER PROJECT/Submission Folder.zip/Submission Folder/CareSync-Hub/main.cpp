#include <iostream>
#include "include/Doctor.h"
#include "include/Patient.h"
#include "include/Appointment.h"
#include "include/Department.h"
#include "include/Utils.h"
using namespace std;

void PrintMenu() {
    cout << "\n";
    cout << "======================================================\n";
    cout << "       CareSync Hub - Hospital Management\n";
    cout << "======================================================\n";
    cout << "\n";
    cout << "  [1]  Display All Doctors\n";
    cout << "  [2]  View Doctor Schedule (by date)\n";
    cout << "  [3]  View Patient Appointments\n";
    cout << "  [4]  Add New Appointment\n";
    cout << "  [5]  Cancel Appointment\n";
    cout << "  [6]  List Reachable Departments\n";
    cout << "  [7]  Find Shortest Referral Path\n";
    cout << "  [8]  View Doctor's Patients (Alphabetical)\n";
    cout << "  [9]  Show Statistics\n";
    cout << "  [10] Save All Data\n";
    cout << "  [0]  Exit\n";
    cout << "\n";
    cout << "======================================================\n";
    cout << "Enter choice: ";
}

int main() {
    cout << "\n*** Loading system data... ***\n";
    
    Doctor* doctorRoot = LoadDoctorsFromFile("data/doctors.txt");
    LoadPatientsFromFile("data/patients.txt");
    LoadReferralsFromFile("data/referrals.txt");
    
    
    cout << "*** System ready! ***\n";
    
    int choice;
    bool running = true;
    
    while (running) {
        PrintMenu();
        cin >> choice;
        
        switch (choice) {
            case 1: {
                cout << "\n========== ALL DOCTORS ==========\n";
                InOrderDoctors(doctorRoot);
                break;
            }
            
            case 2: {
                int doctorId, date;
                cout << "\nEnter Doctor ID: ";
                cin >> doctorId;
                cout << "Enter Date (yyyymmdd): ";
                cin >> date;
                PrintDoctorSchedule(doctorRoot, doctorId, date);
                break;
            }
            
            case 3: {
                int patientId;
                cout << "\nEnter Patient ID: ";
                cin >> patientId;
                PrintPatientAppointments(doctorRoot, patientId);
                break;
            }
            
            case 4: {
                int doctorId, appId, date, startTime, endTime, patientId;
                cout << "\n=== Add New Appointment ===\n";
                cout << "Doctor ID: ";
                cin >> doctorId;
                cout << "Appointment ID: ";
                cin >> appId;
                cout << "Date (yyyymmdd): ";
                cin >> date;
                cout << "Start Time (hhmm): ";
                cin >> startTime;
                cout << "End Time (hhmm): ";
                cin >> endTime;
                cout << "Patient ID: ";
                cin >> patientId;
                
                bool success = AddAppointment(doctorRoot, doctorId, appId, date, startTime, endTime, patientId);
                if (success) {
                    cout << "\n[SUCCESS] Appointment added successfully!\n";
                } else {
                    cout << "\n[FAILED] Could not add appointment (overlap or invalid doctor)\n";
                }
                break;
            }
            
            case 5: {
                int appId;
                cout << "\nEnter Appointment ID to cancel: ";
                cin >> appId;
                CancelAppointment(doctorRoot, appId);
                break;
            }
            
            case 6: {
                char deptName[100];
                cout << "\nEnter Department Name: ";
                cin.ignore();
                cin.getline(deptName, 100);
                ListReachableDepartments(deptName);
                break;
            }
            
            case 7: {
                char fromDept[100], toDept[100];
                cout << "\nEnter Source Department: ";
                cin.ignore();
                cin.getline(fromDept, 100);
                cout << "Enter Target Department: ";
                cin.getline(toDept, 100);
                ShortestReferralPath(fromDept, toDept);
                break;
            }
            
            case 8: {
                int doctorId;
                cout << "\nEnter Doctor ID: ";
                cin >> doctorId;
                PrintDoctorPatientsAlphabetical(doctorRoot, doctorId);
                break;
            }
            
            case 9: {
                ShowStatistics(doctorRoot);
                break;
            }
            
            case 10: {
                SaveAllData(doctorRoot);
                break;
            }
            
            case 0: {
                cout << "\n*** Saving data before exit... ***\n";
                SaveAllData(doctorRoot);
                cout << "\n*** Thank you for using CareSync Hub! ***\n";
                running = false;
                break;
            }
            
            default: {
                cout << "\n[ERROR] Invalid choice. Please try again.\n";
                break;
            }
        }
        
        if (running) {
            cout << "\nPress Enter to continue...";
            cin.ignore();
            cin.get();
        }
    }
    
    return 0;
}