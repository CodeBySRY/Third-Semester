### **Overlap Detection Logic:**

Two appointments overlap if they're on the **same date** AND their times intersect:
```
Overlap occurs when:
  date1 == date2  AND
  (start1 < end2) AND (end1 > start2)
```

**Why this works:**
- `start1 < end2`: Appointment 1 starts before Appointment 2 ends
- `end1 > start2`: Appointment 1 ends after Appointment 2 starts

**Example (integers make this trivial!):**
```
Existing: date=20250618, start=1400, end=1500
New:      date=20250618, start=1430, end=1530

Check: 20250618 == 20250618 ✓
       1430 < 1500 ✓
       1530 > 1400 ✓
→ OVERLAP! Reject appointment.