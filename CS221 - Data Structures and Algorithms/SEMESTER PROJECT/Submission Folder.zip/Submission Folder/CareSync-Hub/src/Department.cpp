#include "../include/Department.h"
#include "../include/Utils.h"
#include <iostream>
using namespace std;

DeptNode* deptHead = nullptr;

DeptNode* GetOrCreateDept(const char* name) {
    DeptNode* curr = deptHead;
    while (curr != nullptr) {
        if (CompareString(curr->name, name) == 0) {
            return curr;
        }
        curr = curr->next;
    }
    
    DeptNode* newDept = new DeptNode;
    newDept->name = CopyString(name);
    newDept->firstEdge = nullptr;
    newDept->next = deptHead;
    deptHead = newDept;
    
    return newDept;
}

void AddReferral(const char* from, const char* to) {
    DeptNode* fromNode = GetOrCreateDept(from);
    DeptNode* toNode = GetOrCreateDept(to);
    
    DeptEdge* newEdge = new DeptEdge;
    newEdge->to = toNode;
    newEdge->next = fromNode->firstEdge;
    fromNode->firstEdge = newEdge;
}

bool IsVisited(DeptNode** visited, int visitedCount, DeptNode* node) {
    for (int i = 0; i < visitedCount; i++) {
        if (visited[i] == node) {
            return true;
        }
    }
    return false;
}

void DFS_Helper(DeptNode* node, DeptNode** visited, int& visitedCount) {
    visited[visitedCount++] = node;
    
    DeptEdge* edge = node->firstEdge;
    while (edge != nullptr) {
        DeptNode* neighbor = edge->to;
        
        if (!IsVisited(visited, visitedCount, neighbor)) {
            cout << "  - " << neighbor->name << "\n";
            DFS_Helper(neighbor, visited, visitedCount);
        }
        
        edge = edge->next;
    }
}

void ListReachableDepartments(const char* startDeptName) {
    DeptNode* startNode = nullptr;
    
    DeptNode* curr = deptHead;
    while (curr != nullptr) {
        if (CompareString(curr->name, startDeptName) == 0) {
            startNode = curr;
            break;
        }
        curr = curr->next;
    }
    
    if (startNode == nullptr) {
        cout << "Department '" << startDeptName << "' not found.\n";
        return;
    }
    
    DeptNode* visited[100];
    int visitedCount = 0;
    visited[visitedCount++] = startNode;
    
    cout << "\nDepartments reachable from " << startDeptName << ":\n";
    
    DeptEdge* edge = startNode->firstEdge;
    bool foundAny = false;
    
    while (edge != nullptr) {
        DeptNode* neighbor = edge->to;
        if (!IsVisited(visited, visitedCount, neighbor)) {
            foundAny = true;
            cout << "  - " << neighbor->name << "\n";
            DFS_Helper(neighbor, visited, visitedCount);
        }
        edge = edge->next;
    }
    
    if (!foundAny) {
        cout << "  (No reachable departments)\n";
    }
}

struct Queue {
    DeptNode* nodes[100];
    int front;
    int back;
    
    Queue() : front(0), back(0) {}
    
    void enqueue(DeptNode* node) {
        nodes[back++] = node;
    }
    
    DeptNode* dequeue() {
        return nodes[front++];
    }
    
    bool isEmpty() {
        return front >= back;
    }
};

struct ParentMap {
    DeptNode* node[100];
    DeptNode* parent[100];
    int count;
    
    ParentMap() : count(0) {}
    
    void set(DeptNode* n, DeptNode* p) {
        node[count] = n;
        parent[count] = p;
        count++;
    }
    
    DeptNode* get(DeptNode* n) {
        for (int i = 0; i < count; i++) {
            if (node[i] == n) {
                return parent[i];
            }
        }
        return nullptr;
    }
};

int ShortestReferralPath(const char* fromDeptName, const char* toDeptName) {
    DeptNode* startNode = nullptr;
    DeptNode* targetNode = nullptr;
    
    DeptNode* curr = deptHead;
    while (curr != nullptr) {
        if (CompareString(curr->name, fromDeptName) == 0) {
            startNode = curr;
        }
        if (CompareString(curr->name, toDeptName) == 0) {
            targetNode = curr;
        }
        curr = curr->next;
    }
    
    if (startNode == nullptr) {
        cout << "Start department '" << fromDeptName << "' not found.\n";
        return -1;
    }
    if (targetNode == nullptr) {
        cout << "Target department '" << toDeptName << "' not found.\n";
        return -1;
    }
    
    Queue q;
    DeptNode* visited[100];
    int visitedCount = 0;
    ParentMap parentMap;
    
    q.enqueue(startNode);
    visited[visitedCount++] = startNode;
    parentMap.set(startNode, nullptr);
    
    while (!q.isEmpty()) {
        DeptNode* current = q.dequeue();
        
        if (current == targetNode) {
            DeptNode* path[100];
            int pathLength = 0;
            
            DeptNode* node = targetNode;
            while (node != nullptr) {
                path[pathLength++] = node;
                node = parentMap.get(node);
            }
            
            cout << "\nShortest referral path from " << fromDeptName 
                 << " to " << toDeptName << ":\n";
            cout << "Path: ";
            for (int i = pathLength - 1; i >= 0; i--) {
                cout << path[i]->name;
                if (i > 0) cout << " -> ";
            }
            cout << "\n";
            cout << "Length: " << (pathLength - 1) << " referral(s)\n";
            
            return pathLength - 1;
        }
        
        DeptEdge* edge = current->firstEdge;
        while (edge != nullptr) {
            DeptNode* neighbor = edge->to;
            
            if (!IsVisited(visited, visitedCount, neighbor)) {
                visited[visitedCount++] = neighbor;
                parentMap.set(neighbor, current);
                q.enqueue(neighbor);
            }
            
            edge = edge->next;
        }
    }
    
    cout << "\nNo referral path exists from " << fromDeptName 
         << " to " << toDeptName << ".\n";
    return -1;
}