#include "../include/Appointment.h"
#include "../include/Doctor.h"
#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>

using namespace std;

// Create a new appointment node
Appointment* CreateAppointment(int appId, int date, int startTime, 
                               int endTime, int patientId) {
    Appointment* app = new Appointment;
    app->appId = appId;
    app->date = date;
    app->startTime = startTime;
    app->endTime = endTime;
    app->patientId = patientId;
    app->next = nullptr;
    return app;
}

// Check if two appointments overlap
bool HasOverlap(int date1, int start1, int end1,
                int date2, int start2, int end2) {
    // Must be same date
    if (date1 != date2) {
        return false;
    }
    
    // Check time overlap
    // Overlap if: start1 < end2 AND end1 > start2
    return (start1 < end2) && (end1 > start2);
}

bool AddAppointment(Doctor* root, int doctorId, int appId, 
                   int date, int startTime, int endTime, int patientId) {
    // Step 1: Find the doctor
    Doctor* doc = FindDoctor(root, doctorId);
    if (doc == nullptr) {
        return false;  // Doctor doesn't exist
    }
    
    // Step 2: Check for overlaps with existing appointments
    Appointment* curr = doc->appointments;
    while (curr != nullptr) {
        if (HasOverlap(date, startTime, endTime,
                      curr->date, curr->startTime, curr->endTime)) {
            return false;  // Overlap detected - reject
        }
        curr = curr->next;
    }
    
    // Step 3: Create the new appointment
    Appointment* newApp = CreateAppointment(appId, date, startTime, 
                                           endTime, patientId);
    
    // Step 4: Insert in sorted order (date, then time)
    
    // Case 1: Empty list or new appointment comes first
    if (doc->appointments == nullptr ||
        date < doc->appointments->date ||
        (date == doc->appointments->date && 
         startTime < doc->appointments->startTime)) {
        
        newApp->next = doc->appointments;
        doc->appointments = newApp;
        return true;
    }
    
    // Case 2: Find correct position in middle/end
    curr = doc->appointments;
    while (curr->next != nullptr) {
        Appointment* next = curr->next;
        
        // Check if newApp should go between curr and next
        if (date < next->date ||
            (date == next->date && startTime < next->startTime)) {
            break;
        }
        
        curr = curr->next;
    }
    
    // Insert after curr
    newApp->next = curr->next;
    curr->next = newApp;
    
    return true;
}

// Requirement 2: Show doctor's schedule for a specific day
void PrintDoctorSchedule(Doctor* root, int doctorId, int date) {
    // Step 1: Find the doctor
    Doctor* doc = FindDoctor(root, doctorId);
    if (doc == nullptr) {
        cout << "Error: Doctor with ID " << doctorId << " not found.\n";
        return;
    }
    
    // Step 2: Print header
    cout << "\n========== Schedule for Dr. " << doc->name 
         << " (ID: " << doctorId << ") on " << date << " ==========\n";
    
    // Step 3: Traverse appointments and filter by date
    Appointment* curr = doc->appointments;
    bool found = false;
    int count = 0;
    
    while (curr != nullptr) {
        if (curr->date == date) {
            found = true;
            count++;
            cout << "  " << count << ". Appointment ID: " << curr->appId
                 << " | Patient ID: " << curr->patientId
                 << " | Time: " << curr->startTime 
                 << " - " << curr->endTime << "\n";
        }
        curr = curr->next;
    }
    
    // Step 4: Handle no appointments case
    if (!found) {
        cout << "  No appointments scheduled for this date.\n";
    }
    
    cout << "======================================================\n";
}

// Helper function for recursive traversal
void PrintPatientAppointmentsHelper(Doctor* root, int patientId, bool& found) {
    if (root == nullptr) {
        return;
    }
    
    // In-order traversal (left, current, right)
    PrintPatientAppointmentsHelper(root->left, patientId, found);
    
    // Check current doctor's appointments
    Appointment* curr = root->appointments;
    while (curr != nullptr) {
        if (curr->patientId == patientId) {
            found = true;
            cout << "  Doctor: " << root->name 
                 << " (ID: " << root->doctorId << ")"
                 << " | Date: " << curr->date
                 << " | Time: " << curr->startTime 
                 << " - " << curr->endTime
                 << " | Appt ID: " << curr->appId << "\n";
        }
        curr = curr->next;
    }
    
    PrintPatientAppointmentsHelper(root->right, patientId, found);
}

// Requirement 3: Show patient's upcoming appointments
void PrintPatientAppointments(Doctor* root, int patientId) {
    cout << "\n========== Appointments for Patient ID: " << patientId 
         << " ==========\n";
    
    bool found = false;
    PrintPatientAppointmentsHelper(root, patientId, found);
    
    if (!found) {
        cout << "  No appointments found for this patient.\n";
    }
    
    cout << "======================================================\n";
}


// Helper function to search and delete from a doctor's list
bool CancelAppointmentFromDoctor(Doctor* doc, int appId) {
    if (doc == nullptr || doc->appointments == nullptr) {
        return false;
    }
    
    Appointment* curr = doc->appointments;
    Appointment* prev = nullptr;
    
    while (curr != nullptr) {
        if (curr->appId == appId) {
            // Found it! Remove from list
            if (prev == nullptr) {
                // Removing head
                doc->appointments = curr->next;
            } else {
                // Removing middle/end
                prev->next = curr->next;
            }
            
            // Free memory
            delete curr;
            return true;
        }
        
        prev = curr;
        curr = curr->next;
    }
    
    return false;  // Not found in this doctor's list
}

// Helper for recursive BST traversal
bool CancelAppointmentHelper(Doctor* root, int appId) {
    if (root == nullptr) {
        return false;
    }
    
    // Try to cancel from current doctor
    if (CancelAppointmentFromDoctor(root, appId)) {
        return true;
    }
    
    // Recursively search left and right subtrees
    if (CancelAppointmentHelper(root->left, appId)) {
        return true;
    }
    
    return CancelAppointmentHelper(root->right, appId);
}

// Requirement 5: Cancel an existing appointment
bool CancelAppointment(Doctor* root, int appId) {
    bool success = CancelAppointmentHelper(root, appId);
    
    if (success) {
        cout << "Appointment ID " << appId << " cancelled successfully.\n";
    } else {
        cout << "Error: Appointment ID " << appId << " not found.\n";
    }
    
    return success;
}





