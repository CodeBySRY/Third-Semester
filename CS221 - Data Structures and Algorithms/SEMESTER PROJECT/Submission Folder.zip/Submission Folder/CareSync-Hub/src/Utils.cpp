#include "../include/Utils.h"
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <iostream>
using namespace std;

char* CopyString(const char* src) {
    int len = 0;
    while (src[len] != '\0') len++;
    char* dest = new char[len + 1];
    for (int i = 0; i < len; i++)
        dest[i] = src[i];
    dest[len] = '\0';
    return dest;
}

int CompareString(const char* a, const char* b) {
    int i = 0;
    while (a[i] && b[i]) {
        if (a[i] != b[i])
            return a[i] - b[i];
        i++;
    }
    return a[i] - b[i];
}

Doctor* LoadDoctorsFromFile(const char* filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "[ERROR] Could not open doctors file.\n";
        return nullptr;
    }
    Doctor* root = nullptr;
    char line[256];
    file.getline(line, sizeof(line));
    while (file.getline(line, sizeof(line))) {
        char* token;
        token = strtok(line, "|");
        int id = atoi(token);
        token = strtok(nullptr, "|");
        char* name = token;
        token = strtok(nullptr, "|");
        char* specialty = token;
        token = strtok(nullptr, "|");
        char* department = token;
        Doctor* d = CreateDoctor(id, name, specialty, department);
        root = InsertDoctor(root, d);
    }
    file.close();
    return root;
}

void LoadPatientsFromFile(const char* filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "[ERROR] Could not open patients file.\n";
        return;
    }
    char line[256];
    file.getline(line, sizeof(line));
    while (file.getline(line, sizeof(line))) {
        char* token;
        token = strtok(line, "|");
        int id = atoi(token);
        token = strtok(nullptr, "|");
        char* first = token;
        token = strtok(nullptr, "|");
        char* last = token;
        Patient* p = CreatePatient(id, first, last);
        InsertPatient(p);
    }
    file.close();
}

void SaveDoctorsToFileHelper(Doctor* root, ofstream& file) {
    if (root == nullptr) return;
    SaveDoctorsToFileHelper(root->left, file);
    file << root->doctorId << "|"
         << root->name << "|"
         << root->specialty << "|"
         << root->departmentName << "\n";
    SaveDoctorsToFileHelper(root->right, file);
}

void SaveDoctorsToFile(Doctor* root, const char* filename) {
    ofstream file(filename);
    if (!file) {
        cout << "Error: Cannot open " << filename << " for writing\n";
        return;
    }
    file << "doctorId|name|specialty|department\n";
    SaveDoctorsToFileHelper(root, file);
    file.close();
}

void SavePatientsToFile(const char* filename) {
    ofstream file(filename);
    if (!file) {
        cout << "Error: Cannot open " << filename << " for writing\n";
        return;
    }
    file << "patientId|firstName|lastName\n";
    for (int i = 0; i < PATIENT_BUCKETS; i++) {
        Patient* curr = patientTable[i];
        while (curr != nullptr) {
            file << curr->patientId << "|"
                 << curr->firstName << "|"
                 << curr->lastName << "\n";
            curr = curr->next;
        }
    }
    file.close();
}

void SaveAppointmentsHelper(Doctor* root, ofstream& file) {
    if (root == nullptr) return;
    SaveAppointmentsHelper(root->left, file);
    Appointment* curr = root->appointments;
    while (curr != nullptr) {
        file << curr->appId << "|"
             << root->doctorId << "|"
             << curr->date << "|"
             << curr->startTime << "|"
             << curr->endTime << "|"
             << curr->patientId << "\n";
        curr = curr->next;
    }
    SaveAppointmentsHelper(root->right, file);
}

void SaveAppointmentsToFile(Doctor* root, const char* filename) {
    ofstream file(filename);
    if (!file) {
        cout << "Error: Cannot open " << filename << " for writing\n";
        return;
    }
    file << "appId|doctorId|date|startTime|endTime|patientId\n";
    SaveAppointmentsHelper(root, file);
    file.close();
}

extern DeptNode* deptHead;

void SaveReferralsToFile(const char* filename) {
    ofstream file(filename);
    if (!file) {
        cout << "Error: Cannot open " << filename << " for writing\n";
        return;
    }
    DeptNode* dept = deptHead;
    while (dept != nullptr) {
        DeptEdge* edge = dept->firstEdge;
        while (edge != nullptr) {
            file << dept->name << "|" << edge->to->name << "\n";
            edge = edge->next;
        }
        dept = dept->next;
    }
    file.close();
}

void SaveAllData(Doctor* doctorRoot) {
    SaveDoctorsToFile(doctorRoot, "data/doctors.txt");
    SavePatientsToFile("data/patients.txt");
    SaveAppointmentsToFile(doctorRoot, "data/appointments.txt");
    SaveReferralsToFile("data/referrals.txt");
    cout << "\nAll data saved successfully!\n";
}

void CountAppointmentsHelper(Doctor* root, Doctor*& maxDoctor, int& maxCount) {
    if (root == nullptr) return;
    CountAppointmentsHelper(root->left, maxDoctor, maxCount);
    int count = 0;
    Appointment* curr = root->appointments;
    while (curr != nullptr) {
        count++;
        curr = curr->next;
    }
    if (count > maxCount) {
        maxCount = count;
        maxDoctor = root;
    }
    CountAppointmentsHelper(root->right, maxDoctor, maxCount);
}

struct DeptCount {
    char name[100];
    int count;
};

void CountByDepartmentHelper(Doctor* root, DeptCount* deptCounts, int& deptCountSize) {
    if (root == nullptr) return;
    CountByDepartmentHelper(root->left, deptCounts, deptCountSize);
    int count = 0;
    Appointment* curr = root->appointments;
    while (curr != nullptr) {
        count++;
        curr = curr->next;
    }
    bool found = false;
    for (int i = 0; i < deptCountSize; i++) {
        if (CompareString(deptCounts[i].name, root->departmentName) == 0) {
            deptCounts[i].count += count;
            found = true;
            break;
        }
    }
    if (!found) {
        int i = 0;
        while (root->departmentName[i] != '\0') {
            deptCounts[deptCountSize].name[i] = root->departmentName[i];
            i++;
        }
        deptCounts[deptCountSize].name[i] = '\0';
        deptCounts[deptCountSize].count = count;
        deptCountSize++;
    }
    CountByDepartmentHelper(root->right, deptCounts, deptCountSize);
}

void ShowStatistics(Doctor* root) {
    cout << "\n========== SYSTEM STATISTICS ==========\n";
    Doctor* maxDoctor = nullptr;
    int maxCount = 0;
    CountAppointmentsHelper(root, maxDoctor, maxCount);
    if (maxDoctor != nullptr) {
        cout << "\nDoctor with most appointments:\n";
        cout << "  " << maxDoctor->name << " (ID: " << maxDoctor->doctorId 
             << ") - " << maxCount << " appointment(s)\n";
    } else {
        cout << "\nNo appointments in system.\n";
    }
    DeptCount deptCounts[100];
    int deptCountSize = 0;
    CountByDepartmentHelper(root, deptCounts, deptCountSize);
    if (deptCountSize > 0) {
        int maxDeptIdx = 0;
        for (int i = 1; i < deptCountSize; i++) {
            if (deptCounts[i].count > deptCounts[maxDeptIdx].count) {
                maxDeptIdx = i;
            }
        }
        cout << "\nBusiest department:\n";
        cout << "  " << deptCounts[maxDeptIdx].name 
             << " - " << deptCounts[maxDeptIdx].count << " appointment(s)\n";
    }
    cout << "=======================================\n";
}

struct PatientName {
    int patientId;
    char fullName[200];
};

void InsertSorted(PatientName* arr, int& size, PatientName newPatient) {
    int i = size - 1;
    while (i >= 0 && CompareString(arr[i].fullName, newPatient.fullName) > 0) {
        arr[i + 1] = arr[i];
        i--;
    }
    arr[i + 1] = newPatient;
    size++;
}

void PrintDoctorPatientsAlphabetical(Doctor* root, int doctorId) {
    Doctor* doc = FindDoctor(root, doctorId);
    if (doc == nullptr) {
        cout << "Doctor with ID " << doctorId << " not found.\n";
        return;
    }
    PatientName patients[100];
    int patientCount = 0;
    Appointment* curr = doc->appointments;
    while (curr != nullptr) {
        bool alreadyAdded = false;
        for (int i = 0; i < patientCount; i++) {
            if (patients[i].patientId == curr->patientId) {
                alreadyAdded = true;
                break;
            }
        }
        if (!alreadyAdded) {
            Patient* patient = FindPatient(curr->patientId);
            if (patient != nullptr) {
                PatientName pn;
                pn.patientId = patient->patientId;
                int idx = 0;
                int i = 0;
                while (patient->firstName[i] != '\0') {
                    pn.fullName[idx++] = patient->firstName[i++];
                }
                pn.fullName[idx++] = ' ';
                i = 0;
                while (patient->lastName[i] != '\0') {
                    pn.fullName[idx++] = patient->lastName[i++];
                }
                pn.fullName[idx] = '\0';
                InsertSorted(patients, patientCount, pn);
            }
        }
        curr = curr->next;
    }
    cout << "\n========== Patients of Dr. " << doc->name 
         << " (Alphabetical) ==========\n";
    if (patientCount == 0) {
        cout << "  No patients found.\n";
    } else {
        for (int i = 0; i < patientCount; i++) {
            cout << "  " << (i + 1) << ". " << patients[i].fullName 
                 << " (ID: " << patients[i].patientId << ")\n";
        }
    }
    cout << "====================================================\n";
}


void LoadReferralsFromFile(const char* filename)
{
    ifstream fin(filename);

    if (!fin.is_open())
    {
        cout << "Error: Could not open referrals file.\n";
        return;
    }

    char line[256];

    while (fin.getline(line, 256))
    {
        // Skip empty lines
        if (strlen(line) == 0)
            continue;

        char fromDept[100];
        char toDept[100];

        int i = 0, j = 0;

        // Extract fromDept (before '|')
        while (line[i] != '|' && line[i] != '\0')
        {
            fromDept[j++] = line[i++];
        }
        fromDept[j] = '\0';

        // Skip '|'
        if (line[i] == '|')
            i++;

        j = 0;

        // Extract toDept (after '|')
        while (line[i] != '\0')
        {
            toDept[j++] = line[i++];
        }
        toDept[j] = '\0';

        // Ensure departments exist
        GetOrCreateDept(fromDept);
        GetOrCreateDept(toDept);

        // Add directed referral
        AddReferral(fromDept, toDept);
    }

    fin.close();
}
