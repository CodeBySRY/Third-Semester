#include "../include/Doctor.h"
#include "../include/Utils.h"
#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

Doctor* CreateDoctor(int id,
                     const char* name,
                     const char* spec,
                     const char* dept) {
    Doctor* d = new Doctor;

    d->doctorId = id;
    d->name = CopyString(name);
    d->specialty = CopyString(spec);
    d->departmentName = CopyString(dept);

    d->appointments = nullptr;
    d->left = d->right = nullptr;

    return d;
}

Doctor* InsertDoctor(Doctor* root, Doctor* newDoc) {
    if (!root) return newDoc;

    if (newDoc->doctorId < root->doctorId)
        root->left = InsertDoctor(root->left, newDoc);
    else
        root->right = InsertDoctor(root->right, newDoc);

    return root;
}

Doctor* FindDoctor(Doctor* root, int doctorId) {
    if (!root || root->doctorId == doctorId)
        return root;

    if (doctorId < root->doctorId)
        return FindDoctor(root->left, doctorId);
    else
        return FindDoctor(root->right, doctorId);
}

void InOrderDoctors(Doctor* root) {
    if (!root) return;

    InOrderDoctors(root->left);
    cout << root->doctorId << " | "
              << root->name << " | "
              << root->specialty << " | "
              << root->departmentName << endl;
    InOrderDoctors(root->right);
}