#include "../include/Patient.h"
#include "../include/Utils.h"
#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

Patient* patientTable[PATIENT_BUCKETS] = { nullptr };

unsigned int HashPatient(int patientId) {
    return patientId % PATIENT_BUCKETS;
}

Patient* CreatePatient(int id, const char* first, const char* last) {
    Patient* p = new Patient;
    p->patientId = id;
    p->firstName = CopyString(first);
    p->lastName  = CopyString(last);
    p->next = nullptr;
    return p;
}

void InsertPatient(Patient* p) {
    unsigned int index = HashPatient(p->patientId);
    p->next = patientTable[index];
    patientTable[index] = p;
}

Patient* FindPatient(int patientId) {
    unsigned int index = HashPatient(patientId);
    Patient* curr = patientTable[index];

    while (curr) {
        if (curr->patientId == patientId)
            return curr;
        curr = curr->next;
    }
    return nullptr;
}

void PrintAllPatients() {
    for (int i = 0; i < PATIENT_BUCKETS; i++) {
        Patient* curr = patientTable[i];
        while (curr) {
            cout << curr->patientId << " "
                 << curr->firstName << " "
                 << curr->lastName << endl;
            curr = curr->next;
        }  // ← Closing brace for while loop
    }  // ← Closing brace for for loop
}  // ← Closing brace for function