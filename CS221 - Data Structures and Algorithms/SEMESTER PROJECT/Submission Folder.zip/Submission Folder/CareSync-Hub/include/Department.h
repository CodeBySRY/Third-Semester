#ifndef DEPARTMENT_H
#define DEPARTMENT_H

struct DeptNode;

struct DeptEdge {
    DeptNode* to;
    DeptEdge* next;
};

struct DeptNode {
    char* name;
    DeptEdge* firstEdge;
    DeptNode* next;
};

DeptNode* GetOrCreateDept(const char* name);
void AddReferral(const char* from, const char* to);
bool IsVisited(DeptNode** visited, int visitedCount, DeptNode* node);
void DFS_Helper(DeptNode* node, DeptNode** visited, int& visitedCount);
void ListReachableDepartments(const char* startDeptName);
int ShortestReferralPath(const char* fromDeptName, const char* toDeptName);
void DFS_Helper(DeptNode* node, DeptNode** visited, int& visitedCount);

#endif
