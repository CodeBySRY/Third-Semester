#ifndef UTILS_H
#define UTILS_H

#include "Doctor.h"
#include "Patient.h"
#include "Department.h"

char* CopyString(const char* src);
int CompareString(const char* a, const char* b);

Doctor* LoadDoctorsFromFile(const char* filename);
void LoadPatientsFromFile(const char* filename);

void SaveDoctorsToFile(Doctor* root, const char* filename);
void SavePatientsToFile(const char* filename);
void SaveAppointmentsToFile(Doctor* root, const char* filename);
void SaveReferralsToFile(const char* filename);
void SaveAllData(Doctor* doctorRoot);

void ShowStatistics(Doctor* root);
void PrintDoctorPatientsAlphabetical(Doctor* root, int doctorId);

void LoadReferralsFromFile(const char* filename);

#endif