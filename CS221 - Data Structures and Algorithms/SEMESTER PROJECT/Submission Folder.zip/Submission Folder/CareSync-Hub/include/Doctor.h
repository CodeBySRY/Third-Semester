#ifndef DOCTOR_H
#define DOCTOR_H

#include "Appointment.h"

struct Doctor {
    int doctorId;
    char* name;
    char* specialty;
    char* departmentName;

    Appointment* appointments;

    Doctor* left;
    Doctor* right;
};

Doctor* CreateDoctor(int id, const char* name,
                     const char* spec, const char* dept);

Doctor* InsertDoctor(Doctor* root, Doctor* newDoc);
Doctor* FindDoctor(Doctor* root, int doctorId);
void     InOrderDoctors(Doctor* root);


#endif
