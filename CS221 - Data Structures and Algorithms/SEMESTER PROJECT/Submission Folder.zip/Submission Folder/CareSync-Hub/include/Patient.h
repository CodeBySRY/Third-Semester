#ifndef PATIENT_H
#define PATIENT_H

const int PATIENT_BUCKETS = 41;

struct Patient {
    int patientId;
    char* firstName;
    char* lastName;

    Patient* next;
};

// Hash table
extern Patient* patientTable[PATIENT_BUCKETS];

// Core functions
unsigned int HashPatient(int patientId);

Patient* CreatePatient(int id, const char* first, const char* last);
void InsertPatient(Patient* p);
Patient* FindPatient(int patientId);
void PrintAllPatients();


#endif
