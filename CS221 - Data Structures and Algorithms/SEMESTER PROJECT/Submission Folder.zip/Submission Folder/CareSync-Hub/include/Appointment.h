#ifndef APPOINTMENT_H
#define APPOINTMENT_H

struct Doctor;

struct Appointment {
    int appId;
    int date;       // yyyymmdd
    int startTime;  // hhmm
    int endTime;    // hhmm
    int patientId;

    Appointment* next;
};

// Core appointment functions
Appointment* CreateAppointment(int appId, int date, int startTime, 
                               int endTime, int patientId);

bool HasOverlap(int date1, int start1, int end1,
                int date2, int start2, int end2);

// These work with the Doctor BST
bool AddAppointment(Doctor* root, int doctorId, int appId, 
                   int date, int startTime, int endTime, int patientId);

void PrintDoctorSchedule(Doctor* root, int doctorId, int date);

void PrintPatientAppointments(Doctor* root, int patientId);

bool CancelAppointment(Doctor* root, int appId);

#endif
