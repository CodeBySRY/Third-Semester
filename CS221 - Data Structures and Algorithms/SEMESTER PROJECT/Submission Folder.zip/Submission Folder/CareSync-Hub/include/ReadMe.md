### 🔑 **Use of `extern` for Global Hash Table**

The `extern` keyword is used with the `patientTable` hash table because:

1. **Global Accessibility**: `patientTable` is a **global variable** that needs to be accessed across multiple source files (e.g., `Patient.cpp`, `Doctor.cpp`, `Appointment.cpp`).

2. **Single Definition Rule**: In C++, a variable can be **declared** multiple times but must be **defined** exactly once. Without `extern`, each file that includes the header would create its own separate copy of `patientTable`, causing linker errors.

3. **Solution**: 
   - **Declaration** (`extern` in header): `extern Patient* patientTable[PATIENT_BUCKETS];`
     - Tells all files: "This variable exists somewhere"
   - **Definition** (in one `.cpp` file): `Patient* patientTable[PATIENT_BUCKETS] = {nullptr};`
     - Actually allocates memory for the hash table

4. **Benefit**: All modules share the **same hash table instance**, ensuring data consistency while avoiding multiple definition errors.