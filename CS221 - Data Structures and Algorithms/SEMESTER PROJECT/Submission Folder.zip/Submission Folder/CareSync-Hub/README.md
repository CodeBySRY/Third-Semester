# 🏥 CareSync Hub

**A Data Structures & Algorithms (DSA) based Hospital Appointment & Referral Management System**

[![Language](https://img.shields.io/badge/Language-C++-blue.svg)](https://isocpp.org/)
[![DSA](https://img.shields.io/badge/Focus-Data%20Structures-green.svg)](https://github.com/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## 📋 Project Overview

CareSync Hub is a **console-based outpatient clinic management system** designed to demonstrate the real-world application of core Data Structures & Algorithms concepts. The system efficiently manages doctors, patients, appointments, and inter-departmental referrals while preventing scheduling conflicts and optimizing resource allocation.

This project serves as a comprehensive educational tool for understanding how fundamental DSA concepts translate into practical healthcare management solutions.

---

## 🧠 Core DSA Concepts Implemented

| Data Structure | Application | Purpose |
|---------------|-------------|---------|
| **Binary Search Trees (BST)** | Doctor records | Efficient storage and retrieval sorted by Doctor ID |
| **Graphs (Adjacency Lists)** | Referral network | Directed connections between departments for patient referrals |
| **Hash Tables** | Patient lookup | O(1) average-case patient retrieval by Patient ID |
| **Linked Lists** | Appointment scheduling | Time-sorted appointments for each doctor and patient |
| **Sorting Algorithms** | Data organization | Alphabetical patient lists and time-based appointment scheduling |

---

## ✨ Key Features

- ✅ **Doctor Management** – Add, search, and manage doctor records using BST
- ✅ **Patient Registration** – Fast patient lookup and registration via hash tables
- ✅ **Appointment Scheduling** – Conflict-free appointment booking with linked lists
- ✅ **Referral System** – Inter-departmental patient referrals using graph traversal
- ✅ **Conflict Prevention** – Automatic detection of scheduling conflicts
- ✅ **Resource Optimization** – Efficient allocation of doctor time slots

---
